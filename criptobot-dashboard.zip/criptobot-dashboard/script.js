
function ativarBot() {
    document.getElementById("status").innerText = "Status: ✅ Ativado";
    alert("Bot ativado com sucesso!");
}
